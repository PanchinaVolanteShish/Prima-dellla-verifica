import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello world!");

        //Creo e riempo l'ArrayList
        ArrayList<String> list = new ArrayList<String>();
        list.add("1");
        list.add("2");
        list.add("3");


        //Creo e aggiungo valori ai nodi
        Nodo<String> nodo1, nodo2; //Tipo di nodo;
        List<String> list1;
        list1 = new List<>(list); //Non serve scrivere String
        nodo1 = new Nodo<String>("Matteo");
        nodo2 = new Nodo<String>("Galdini");
        System.out.println(nodo1);
        System.out.println(nodo2);
        nodo1.setNext(nodo2); //Matteo diventa Galdini
        System.out.println(list1);
        list1.addHead(new Nodo<String>("1"));
        list1.addHead(new Nodo<String>("2"));
        //list1.addHead("3");
        //list1.addHead("4");
        list1.addTail(new Nodo<String>("5"));
        list1.addTail("6");
        list1.addTail("6");

        //Elimino tutte le occorrenze
        list1.remove("6");

        //Sostituisco primo e ultimo
        String last = list1.lastFirst();
        String first = list1.firstLast();
        list1.remove(first);
        list1.remove(last);
        list1.addHead(last);
        list1.addTail(first);

        //Stampo la lista
        System.out.println(list1);
    }
}