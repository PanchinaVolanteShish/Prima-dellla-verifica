import java.util.*;


public class List<T> {

    //Attributi
    Nodo<T> head; //Parte alta della lista

    //Costruttore
    public List(ArrayList<String> list){
        for (int i = list.size() - 1; i >= 0; i--){
            addTail((T) list.get(i));
        }
        for(String s : list){
            System.out.print(s + " ");
        }
        System.out.println(" ");
        this.head = null;
    }

    //Metodi
    public void addHead(Nodo<T> nx){ // nx --> nodo di x
        nx.setNext(head);
        head = nx;
    }

    public void addHead(T valore){
        Nodo<T> nuovo = new Nodo(valore);
        addHead(nuovo);
    }

    public void addTail(Nodo<T> nx){
        if(head == null){
            head = nx;
            return;
        }
        Nodo<T> p = head;
        while(p.getNext() != null){
            p = p.getNext();
        }
        p.setNext(nx);
    }

    public void addTail(T valore){
        Nodo<T> nuovo = new Nodo(valore);
        addTail(nuovo);
    }

    public void remove(T valore) throws Exception {
        if (head == null) {
            throw new Exception("Elemento non trovato");
        }

        // Rimuovi tutti i nodi corrispondenti all'inizio della lista
        while (head != null && head.getV().equals(valore)) {
            head = head.getNext();
        }

        // Itera sugli altri nodi per rimuovere tutte le occorrenze
        Nodo<T> p = head;
        while (p != null && p.getNext() != null) {
            if (p.getNext().getV().equals(valore)) {
                p.setNext(p.getNext().getNext());
            } else {
                p = p.getNext();
            }
        }
    }

    public T lastFirst() throws Exception {
        if(head == null){
            throw new Exception("Elemento non trovato");
            //return;
        }
        Nodo<T> p1 = head;
        Nodo<T> p2 = head.getNext();
        while (p2.getNext() != null){
            p2 = p2.getNext();
        }
        return p2.getV();
    }

    public T firstLast() throws Exception {
        if(head == null){
            throw new Exception("Elemento non trovato");
            //return;
        }
        Nodo<T> p1 = head;
        Nodo<T> p2 = head.getNext();
        return p1.getV();
    }

    @Override //Altro toString(){}
    public String toString(){
        String s = "La lista continua ";
        Nodo<T> p = head; //Puntatore che parte dalla testa head
        while (p != null){
            s = s + p + " ";
            p = p.getNext(); //Modo per andare avanti nelle liste
        }
        return s;
    }
}
