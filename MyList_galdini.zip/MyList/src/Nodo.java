public class Nodo <T> {

    //Attributi
    int t; //Generic
    T v; //Valore di tipo T

    Nodo<T> next;



    //Costruttore
    public Nodo(T v){
        this.v = v;
        this.next = null; //Next non è un valore che stiamo passando
    }

    //Metodo
    public T getV(){
        return v;
    }
    public void setV(T v){
        this.v = v;
    }
    public Nodo<T> getNext(){
        return next;
    }
    public void setNext(Nodo<T> next){
        this.next = next;
    }
    public String toString(){
        return v.toString();
    }

}
